If you have a cue/bin file then you just need to use daemon tools or such virtual CD drive tools.

Rip your orignal CD for PSP-HUGO using the following command :

TurboRip.exe /PCEP /RS=22050

Then copy the generated folder (with .toc, .mp3 and .iso file) in the cd-roms psp hugo folder

Enjoy,                       Zx