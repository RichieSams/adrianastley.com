/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#include "config.h"
#include <argp.h>
#include <stdlib.h>

int init_cd(char* device);
int tracks_number(int* min_track, int* max_track);
int track_info(int track_number, int* type, int* lba_begin);
int sector_read(int sector_number, char* sector_data);
int close_cd();

//! program header for GNU argp function
const char *argp_program_version = "dumpcd 0.1";

//! bug report address for GNU argp function
const char *argp_program_bug_address = "<zeograd@zeograd.com>";

//! Program documentation
static char doc[] =
 "dumpcd -- a program to dump data tracks from CD in mode1/2048 form";

//! A description of the arguments we accept
static char args_doc[] = "";

//! The options we understand
static struct argp_option options[] = {
 {"device",        'd', "DEVICE", 0, "Device of the cdrom drive (default \"/dev/cdrom\")" },
 {"prefix-output", 'o', "PREFIX", 0, "Prefix output of files (default \"track\")" },
 { 0 }
};

//! Used by `main' to communicate with `parse_opt'
struct arguments
{
	char* device;
	char* prefix;
};

//! Parse a single option
static error_t
parse_opt (int key, char *arg, struct argp_state *state)
{
 /* Get the INPUT argument from `argp_parse', which we
		know is a pointer to our arguments structure. */
 struct arguments *arguments = state->input;

 switch (key)
	{
	 case 'd':
		arguments->device = arg;
		break;

	 case 'o':
		arguments->prefix = arg;
		break;

	 case ARGP_KEY_ARG:
		if (state->arg_num >= 0)
			/* Too many arguments. */
			argp_usage (state);
		break;

	default:
		return ARGP_ERR_UNKNOWN;
	 }
 return 0;
}

//! Our argp parser
static struct argp argp = { options, parse_opt, args_doc, doc };

int dump_track(char* filename, int begin_sector, int last_sector)
	{
		int sector_index;
		FILE* output_file;
		char sector_data[2048];
		
		output_file = fopen(filename, "wb");
		
		if (output_file == NULL)
			{
				return 1;
			}
			
		for (sector_index = begin_sector; sector_index < last_sector; sector_index++)
			{
				if (sector_read(sector_index, sector_data) != 0)
					{
						fprintf(stderr, "Error reading sector %d\n", sector_index);
						return 1;
					}
					
				fwrite(sector_data, 2048, 1, output_file);
			}
			
		fclose(output_file);
		
		return 0;
	}

int main(int argc, char* argv[])
	{
		struct arguments arguments;
			
		arguments.device = "/dev/cdrom";
		arguments.prefix = "track";
		
		argp_parse (&argp, argc, argv, 0, 0, &arguments);
			
		if (init_cd(arguments.device) == 0)
			{
				int first_track, last_track, track_index;
				
				fprintf(stderr, "CD drive initialized\n");
				
				if (tracks_number(&first_track, &last_track) == 0)
					{
					
						fprintf(stderr, "Tracks %d - %d\n", first_track, last_track);
						
						if ((first_track < 1) || (first_track > 99))
							{
								fprintf(stderr, "First track is in abnormal range\n");
							}
							
						if ((last_track < 1) || (last_track > 99))
							{
								fprintf(stderr, "Last track is in abnormal range\n");
							}
							
						if (last_track < first_track)
							{
								int temp;
								
								fprintf(stderr, "Tracks in abnormal sense\n");
								
								temp = first_track;
								first_track = last_track;
								last_track = temp;
							}
							
						for (track_index = first_track; track_index <= last_track; track_index++)
							{
								int begin_lba;
								int end_lba;
								int track_type;
								
								track_info(track_index, &track_type, &begin_lba);
							  if (track_index == last_track)
									track_info(0xAA, NULL, &end_lba);
								else
									track_info(track_index + 1, NULL, &end_lba);
								
								#if defined(DEBUG)
								fprintf(stderr, "Track #%d type 0x%02x from %d to %d\n", track_index, track_type, begin_lba, end_lba);
								#endif
								
								printf("Track #%d: ", track_index);
								
								if (track_type & 0x04)
									{
										char* filename;
										
										puts("Code track, dumping...");
										
										filename = malloc(strlen(arguments.prefix) + 3 + strlen(".iso") + 1);
										
										snprintf(filename, strlen(arguments.prefix) + 3 + strlen(".iso") + 1,
											"%s_%02d.iso", arguments.prefix, track_index);
										
										if (dump_track(filename, begin_lba, end_lba) == 0)
											{
												printf("Successful rip of track %d\n", track_index);
											}
									}
								else
									{
										puts("Audio track, skipping...");
									}
							}
							
					} // tracks_number successful
					
				close_cd();
					
			} // init_cd successful
			
		return 0;
	}
