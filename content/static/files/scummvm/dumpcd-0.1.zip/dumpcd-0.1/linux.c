/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#include "config.h"

#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <linux/cdrom.h>
#include <sys/ioctl.h>
#include <unistd.h>

//! The internal cd drive handle
static int cd_drive_handle;

int init_cd(char* device)
{
	cd_drive_handle = open(device, O_RDONLY | O_NONBLOCK);
	
	return cd_drive_handle != (int)NULL ? 0 : 1;
}

int tracks_number(int* min_track, int* max_track)
{
  struct cdrom_tochdr track_info;

  if (ioctl(cd_drive_handle, CDROMREADTOCHDR, &track_info) == -1)
		{
    	perror("tracks_number");
		  return 1;
		}

  *min_track = track_info.cdth_trk0;
  *max_track = track_info.cdth_trk1;	
	
	return 0;
}

int track_info(int track_number, int* type, int* lba_begin)
{
  struct cdrom_tocentry tocentry;
  
  tocentry.cdte_track = track_number;
  tocentry.cdte_format = CDROM_MSF;

  if (ioctl(cd_drive_handle, CDROMREADTOCENTRY, &tocentry) == -1)
		{
    	perror("track_info");
			return 1;
		}

  *lba_begin = (((tocentry.cdte_addr.msf.minute * 60) + tocentry.cdte_addr.msf.second) * 75) + tocentry.cdte_addr.msf.frame - 150;
	if (type != NULL)
  	*type = tocentry.cdte_ctrl;	
	
	return 0;
}

int sector_read(int sector_number, char* sector_data)
{
	int retries = 0;
  char buf[128];

  while ((lseek(cd_drive_handle, 2048 * sector_number, SEEK_SET) < 0) && (retries < 3)) {
    snprintf(buf, sizeof(buf), "sector_read:lseek (sector=%d, retry=%d)", sector_number, retries);
    perror(buf);
    retries++;
  }

  while ((read(cd_drive_handle, sector_data, 2048) < 0) && (retries++ < 3)) {
    snprintf(buf, sizeof(buf), "sector_read:read (sector=%d, retry=%d)", sector_number, retries);
    perror(buf);
  }

	return retries >= 3 ? 1 : 0;

}

int close_cd()
{
	close(cd_drive_handle);
	return 0;	
}
